int main()
{
    int x;
    int y=1;

    x += y;

}
